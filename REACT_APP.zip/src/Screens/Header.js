import React, { useEffect } from "react";
import { connect } from "react-redux";

function Header(params) {
    
        return (

            <div className="app-content content">
            </div>

        );
} 

export default connect()(Header)
