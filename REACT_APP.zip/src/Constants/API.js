class API {
  static BASE_URL = "http://localhost:1000";

  static key = "Asdiuailsdjk";
  static LOGIN = "/auth/login";
  static REGISTER = "/auth/reg";





  static ADMIN_USER = "/admin/allusers";
  static ADMIN_DELETE_USER = "/admin/deleteuser";
  static ADMIN_LOGIN = "/admin/login";
  static ADMIN_REGISTER = "/admin/reg";

  



}

export default API;
